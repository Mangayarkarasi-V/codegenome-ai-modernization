01 EMPLOYEE-RECORD.
          05 EMPLOYEE-ID              PIC 9(5).
          05 EMPLOYEE-NAME            PIC X(30).
          05 EMPLOYEE-DEPARTMENT      PIC X(20).
          05 EMPLOYEE-SALARY          PIC 9(7).
          05 EMPLOYEE-GRADE           PIC X(2).
          05 EMPLOYEE-STATUS          PIC X(10).
          05 EMPLOYEE-JOIN-DATE.
             10 JOIN-YEAR             PIC 9(4).
             10 JOIN-MONTH            PIC 9(2).
             10 JOIN-DAY              PIC 9(2).
          05 EMPLOYEE-BANK-DETAILS.
             10 BANK-ID               PIC X(10).
             10 ACCOUNT-NUMBER        PIC X(18).
          05 EMPLOYEE-TAX-DETAILS.
             10 TAX-CODE              PIC X(5).
             10 TAX-AMOUNT            PIC 9(5).
             10 NET-SALARY            PIC 9(7).